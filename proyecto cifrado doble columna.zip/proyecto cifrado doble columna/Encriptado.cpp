//---------------------------------------------------------------------------

#pragma hdrstop

#include "Encriptado.h"
#include <vector>

//---------------------------------------------------------------------------
#pragma package(smart_init)
	Encriptado::Encriptado()
	{
		clave1 = "";
		clave2 = "";
		cifrado= "";
	}
	int Encriptado::posicion_clave(wchar_t clave)
	{
	   String x = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ";
	   wchar_t letra = towupper(clave);
	   int pos = x.Pos(letra);
	   return pos;

	}
	String Encriptado::menor(String clave)
	{
	  int a = 1;     String x = clave; wchar_t aux ;
		for (int i = a; i < clave.Length(); i++)
		{
			int b = a;
			for (int c = b; c < clave.Length(); c++)
			{
				int d = posicion_clave(x[c]);
				int e = posicion_clave(x[c+1]);
				if(d > e)
				{
					aux = x[c];
					x[c] = x[c+1];
					x[c+1]= aux;

				}
			}
		}
		return x;
	}

	String Encriptado::separador(String texto)
	{
	 String a = "";
	 for (int i = 1; i <= texto.Length(); i++)
	 {
		  wchar_t c = texto[i];
		  switch (c)
		   {
				case L'�': case L'�': case L'�': case L'�': c = L'A'; break;
				case L'�': case L'�': case L'�': case L'�': c = L'E'; break;
				case L'�': case L'�': case L'�': case L'�': c = L'I'; break;
				case L'�': case L'�': case L'�': case L'�': c = L'O'; break;
				case L'�': case L'�': case L'�': case L'�': case L'�': case L'�': c = L'U'; break;
				case L'�': case L'�': c = L'�'; break;
		   }
		   if (iswalpha(c) || c == L'�')
			{
				a += towupper(c);
		   }
	 }
		return a;
	}
void Encriptado::matriz(String claveLimpia, String textoLimpio)
{
	if (claveLimpia.IsEmpty() || textoLimpio.IsEmpty()) return;

	// Calculamos dimensiones
	C = claveLimpia.Length();
	int filasTexto = (textoLimpio.Length() + C - 1) / C;
	F = filasTexto + 1; // +1 para la Fila 0 (Clave)

	// Limpiamos y redimensionamos la matriz global del .h
	tabla.clear();
	tabla.assign(F, "");

	// Cargar Fila 0 (Clave)
	for (int c = 1; c <= C; c++) {
		tabla[0] += claveLimpia[c];
	}

	// Cargar Filas 1 a F-1 (Texto)
	int posTexto = 1;
	for (int f = 1; f < F; f++) {
		for (int c = 1; c <= C; c++) {
			if (posTexto <= textoLimpio.Length()) {
				tabla[f] += textoLimpio[posTexto++];
			} else {
				tabla[f] += L'X'; // Relleno
			}
		}
	}
	// �La matriz queda guardada en "this->tabla" lista para usarse!
}
String Encriptado::Encri(TStringGrid *grid1, TStringGrid *grid2)
{
	// Limpiamos directamente la variable miembro 'cifrado'
	cifrado = separador(cifrado);
	String cla = separador(clave1);
	longtexto1= cifrado.Length();

	for (int i = 1; i <= 2; i++)
	{
		String x = cifrado; // El texto actual que se usar� para la matriz

        // Validaciones sobre la variable de la clase
        if (cla.IsEmpty() || x.IsEmpty())
            throw Exception("Error: La clave o el texto no pueden estar vacios");

        if (cla.Length() > x.Length())
            throw Exception("Error: La clave no puede ser mayor al contenido del texto");

		// Cargamos la matriz con la clave actual y el texto de 'cifrado'
		matriz(cla, x);

        if (i == 1) {
			mostrarEnGrid(grid1, cla); // Pasada 1 -> Muestra clave1 y matriz 1
		} else {
			mostrarEnGrid(grid2, cla); // Pasada 2 -> Muestra clave2 y matriz 2
		}

		// Clave ordenada
		String men = menor(cla);

        String nuevoCifrado = "";
		int colBusqueda = 1; // Puntero circular continuo

		//  Recorrido de lectura columna por columna
        for (int a = 1; a <= men.Length(); a++)
		{
			wchar_t letraBuscada = men[a];

            // Buscamos la letra en la Fila 0
			while (tabla[0][colBusqueda] != letraBuscada)
            {
                colBusqueda++;
                if (colBusqueda > C)
                {
                    colBusqueda = 1; // Reinicio circular si llega al final
				}
			}

			// Extraemos la columna encontrada
            for (int f = 1; f < F; f++)
            {
                nuevoCifrado += tabla[f][colBusqueda];
			}

			// Avanzamos uno para no repetir la misma columna en la siguiente b�squeda
			colBusqueda++;
			if (colBusqueda > C)
			{
				colBusqueda = 1;
			}
		}

		//  Sobrescribimos el atributo cifrado con el resultado de esta pasada
		cifrado = nuevoCifrado;

		// Cambiamos a la segunda clave para la 2da interacci�n del for
		cla = separador(clave2);
	}

	return cifrado; // Devuelve el cifrado final

}
void Encriptado::mostrarEnGrid(TStringGrid *grid, String clave)
{

    // Configurar dimensiones del Grid (+1 fila si quieres ver la clave arriba)
    grid->ColCount = C;
    grid->RowCount = F;

	// 1. Mostrar la clave en la primera fila (Fila 0)
    for (int c = 1; c <= C; c++) {
        grid->Cells[c - 1][0] = String(clave[c]);
    }

    // 2. Mostrar el contenido de la matriz (Filas 1 a F-1)
    for (int f = 1; f < F; f++) {
        for (int c = 1; c <= C; c++) {
            // Se resta 1 porque TStringGrid usa �ndices base 0 (Columna 0, Fila 0)
            grid->Cells[c - 1][f] = String(tabla[f][c]);
        }
    }
}

String Encriptado::DesEncri()
{
    String cla = clave2;
	int longitudTexto = cifrado.Length();

	for (int i = 1; i <= 2; i++)
	{
		 C = cla.Length();
		 int filasTexto = (longitudTexto + C - 1) / C;
		 F = filasTexto + 1;

		 tabla.clear();
		 tabla.resize(F);

		 tabla[0] = cla;

		 for (int f = 1; f < F; f++) {
			 tabla[f] = String::StringOfChar(L' ', C);
		 }

		 String claOrd = menor(cla);
		 String nuevoCifra = "";
		 int col = 1;
		 int cont = 1;

		 for (int a = 1; a <= claOrd.Length(); a++)
		 {
			wchar_t letraBuscada = claOrd[a];

			while (tabla[0][col] != letraBuscada)
			{
				col++;
				if (col > C) col = 1;
			}

			for (int f = 1; f < F; f++)
			{
				wchar_t caracterAAgregar;

				if (cont <= cifrado.Length() && cont <= longitudTexto)
				{
					caracterAAgregar = cifrado[cont];
					cont++;
				}
				else
				{
					caracterAAgregar = L'X';
				}

				tabla[f][col] = caracterAAgregar;
			}

			col++;
			if (col > C) col = 1;
		 }

		 for (int fil = 1; fil < F; fil++)
		 {
			nuevoCifra += tabla[fil];
		 }

		 cifrado = nuevoCifra;
		 cla = clave1;

		 // Calculamos las filas exactas usando longtexto1 y las multiplicamos por las columnas de clave1
		 int filasClave1 = (longtexto1 + clave1.Length() - 1) / clave1.Length();
		 longitudTexto = filasClave1 * clave1.Length(); // Da exactamente 20 (4 x 5)
	}

	return cifrado;
}

