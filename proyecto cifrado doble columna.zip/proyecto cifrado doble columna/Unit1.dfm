object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Clave 2'
  ClientHeight = 813
  ClientWidth = 997
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Segoe UI'
  Font.Style = [fsBold]
  TextHeight = 21
  object Label1: TLabel
    Left = 230
    Top = 35
    Width = 59
    Height = 21
    Caption = ' Clave 1'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 680
    Top = 35
    Width = 55
    Height = 21
    Caption = 'Clave 2'
  end
  object Label3: TLabel
    Left = 680
    Top = 132
    Width = 80
    Height = 21
    Caption = 'Resultado:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 144
    Top = 315
    Width = 138
    Height = 21
    Caption = 'matriz con clave 1'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label5: TLabel
    Left = 676
    Top = 315
    Width = 138
    Height = 21
    Caption = 'matriz con clave 2'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Button1: TButton
    Left = 144
    Top = 107
    Width = 153
    Height = 57
    Caption = 'cifrar mensaje'
    TabOrder = 0
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 40
    Top = 178
    Width = 401
    Height = 111
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = []
    ParentFont = False
    ScrollBars = ssVertical
    TabOrder = 1
  end
  object Edit1: TEdit
    Left = 120
    Top = 62
    Width = 273
    Height = 29
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
  end
  object Edit2: TEdit
    Left = 568
    Top = 62
    Width = 273
    Height = 29
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
  end
  object Memo2: TMemo
    Left = 520
    Top = 178
    Width = 417
    Height = 111
    Lines.Strings = (
      '')
    ScrollBars = ssVertical
    TabOrder = 4
  end
  object Memo3: TMemo
    Left = 48
    Top = 664
    Width = 393
    Height = 129
    DragCursor = crHelp
    Lines.Strings = (
      'Memo3')
    ScrollBars = ssVertical
    TabOrder = 5
  end
  object Button2: TButton
    Left = 160
    Top = 601
    Width = 129
    Height = 41
    Caption = 'Descifrar'
    TabOrder = 6
    OnClick = Button2Click
  end
  object StringGrid1: TStringGrid
    Left = 72
    Top = 352
    Width = 353
    Height = 193
    TabOrder = 7
  end
  object StringGrid2: TStringGrid
    Left = 552
    Top = 342
    Width = 369
    Height = 203
    TabOrder = 8
  end
end
