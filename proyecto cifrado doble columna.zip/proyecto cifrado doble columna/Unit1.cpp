//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	E.clave1 = Edit1->Text;
	E.clave2 = Edit2->Text;
	E.cifrado =Memo1->Text;
	Memo2->Text= E.Encri(StringGrid1, StringGrid2);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
	Memo3->Text = E.DesEncri();
}
//---------------------------------------------------------------------------


