//---------------------------------------------------------------------------

#ifndef EncriptadoH
#define EncriptadoH
#include <vcl.h>
#include <vector>
#include <Vcl.Grids.hpp>
//---------------------------------------------------------------------------
class Encriptado
{
	private:

	int F;
	int C;
	std::vector<String> tabla;
	int longtexto1;
	public:
    	String cifrado;
	String clave1;
	String clave2;
	Encriptado();
	int posicion_clave(wchar_t clave);
	String menor(String clave);
	String separador(String texto);
	void matriz(String claveLimpia, String textoLimpio);
	String Encri(TStringGrid *grid1, TStringGrid *grid2);
	String DesEncri();
	void mostrarEnGrid(TStringGrid *grid, String clave);


};
#endif
